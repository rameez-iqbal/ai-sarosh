-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 01, 2024 at 01:26 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `aisarosh`
--

-- --------------------------------------------------------

--
-- Table structure for table `articles`
--

CREATE TABLE `articles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `sub_title` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `redirect_url` varchar(255) DEFAULT NULL,
  `article_date` date DEFAULT NULL,
  `library_type_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `articles`
--

INSERT INTO `articles` (`id`, `title`, `sub_title`, `image`, `redirect_url`, `article_date`, `library_type_id`, `created_at`, `updated_at`) VALUES
(2, 'First ever Bengali Medical GPT ‘Susatho.AI’ launched in Bangladesh', 'Tech World Bangladesh', 'rmEcfXrSR2Ob7TGKU4kbmIF9RCYUJ9dmyvk4nWVY.png', 'https://techworldbd24.com/techworld/2002', '2024-05-28', 5, '2024-09-26 01:20:54', '2024-09-30 03:22:06'),
(3, 'AI solutions improving sexual and reproductive health across the Global South', 'Chaitali Sinha, Cintia Cejas, Elizabeth Oseku, Nour El Arnaout, Mohammad Imran', 'QL46vybp128RJPFhovoxTZJBiqU3oA8QqN24RvD4.png', 'https://idrc-crdi.ca/en/research-in-action/ai-solutions-improving-sexual-and-reproductive-health-across-global-south', '2024-06-03', 5, '2024-09-26 01:34:46', '2024-09-30 03:21:45');

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE `countries` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `countries`
--

INSERT INTO `countries` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Bangladesh', '2024-09-11 07:52:09', '2024-09-11 07:52:29'),
(2, 'Pakistan', '2024-09-11 07:52:09', '2024-09-11 07:52:29'),
(3, 'Sri Lanka', '2024-09-11 07:52:09', '2024-09-11 07:52:29'),
(4, 'Nepal', '2024-09-11 07:52:09', '2024-09-11 07:52:29');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `frontend_roles`
--

CREATE TABLE `frontend_roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `role` varchar(255) NOT NULL,
  `bg_color` varchar(255) NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `galleries`
--

CREATE TABLE `galleries` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `library_types`
--

CREATE TABLE `library_types` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `type` varchar(255) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `library_types`
--

INSERT INTO `library_types` (`id`, `type`, `slug`, `image`, `created_at`, `updated_at`) VALUES
(1, 'Webinars', 'webinars', 'Ux6HBO4CMWSdcqL1rPge52kIhKP7IrDwesiBWMLM.svg', '2024-09-24 06:35:43', '2024-09-24 06:35:43'),
(2, 'Reports', 'reports', 'PpHs56vFjNRRIobms3hV5rCP8xXCpcxPFT9jyk3A.svg', '2024-09-24 06:36:03', '2024-09-24 06:36:03'),
(3, 'Gallery', 'gallery', 'Ic0y148vMfCS8MSzeFsWd3GmyaXvDqLoDfZjJDZ2.svg', '2024-09-24 06:38:29', '2024-09-24 06:38:29'),
(4, 'Videos', 'videos', 'NtazyrSHKLBClZmUnr8CNTu7PRn0LoK9A9GugKjp.svg', '2024-09-24 06:39:03', '2024-09-24 06:39:03'),
(5, 'Articles', 'articles', 'VTFNMlHxk0izZlLGeMxAqhA12PuhyhYVt7On4XrL.svg', '2024-09-24 06:39:23', '2024-09-24 06:39:23');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_reset_tokens_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(6, '2024_09_09_104202_create_countries_table', 1),
(9, '2024_09_09_105904_create_frontend_roles_table', 1),
(10, '2024_09_09_105908_create_teams_table', 1),
(11, '2024_09_09_110241_create_galleries_table', 1),
(12, '2024_09_09_114828_create_services_table', 1),
(13, '2024_09_09_115333_create_partners_table', 1),
(14, '2024_09_09_120058_create_thematic_areas_table', 1),
(15, '2024_09_10_094110_create_sections_table', 2),
(16, '2024_09_04_202840_create_pages_table', 3),
(17, '2024_09_10_121958_create_settings_table', 4),
(18, '2024_09_11_044832_create_our_clients_table', 5),
(21, '2024_09_09_104212_create_projects_table', 7),
(22, '2024_09_09_104753_create_project_details_table', 8),
(26, '2024_09_24_050238_create_our_team_roles_table', 9),
(27, '2024_09_24_051222_create_our_teams_table', 9),
(28, '2024_09_24_102242_create_library_types_table', 10),
(29, '2024_09_24_102423_create_webinars_table', 10),
(30, '2024_09_25_121307_add_date_column_in_webinars_table', 11),
(31, '2024_09_26_051048_create_articles_table', 12),
(32, '2024_09_26_070122_create_videos_table', 13),
(33, '2024_09_27_103700_create_reports_table', 14);

-- --------------------------------------------------------

--
-- Table structure for table `our_clients`
--

CREATE TABLE `our_clients` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `our_clients`
--

INSERT INTO `our_clients` (`id`, `image`, `description`, `created_at`, `updated_at`) VALUES
(1, '6e23fb1f-c2c0-4ebe-ac75-07f80db05426.svg', 'PHC Global works towards enabling collaborators and clients to facilitate the well-being of people, communities, and the environment through a system approach, evidence-based research technology, and innovative practices.', '2024-09-11 00:33:28', '2024-09-11 00:33:28'),
(2, 'c6ee8641-9446-4739-be23-8ce4008ed42c.svg', 'Group for Technical Assistance (GTA) provides technical assistance to development factors for better efficiency and effectiveness in the way development activities are carried out in Nepal.', '2024-09-11 00:33:50', '2024-09-11 01:20:20');

-- --------------------------------------------------------

--
-- Table structure for table `our_teams`
--

CREATE TABLE `our_teams` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `image` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `designation` varchar(255) NOT NULL,
  `our_team_roles_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `our_teams`
--

INSERT INTO `our_teams` (`id`, `image`, `name`, `designation`, `our_team_roles_id`, `created_at`, `updated_at`) VALUES
(1, 'JKY2vYfz7eRaF5rMDd7gyV35pJss8RgIUeE1fCcC.png', 'Dr. Mohammad Imran Khan', 'Project lead', 1, '2024-09-24 02:19:27', '2024-09-30 01:14:55'),
(2, 'DxVPnC6oSjxHUX75j0l3LJVDTe8q4Bj4i0NGwLDl.png', 'Mr. Deepak Bajracharya', 'Project Co-Lead', 1, '2024-09-24 02:24:52', '2024-09-30 01:15:53'),
(3, '6MZnyNTXCnMrUjprQZTtJuA80FBucNUFhuhtEupx.png', 'Dr. Noor Sabah Rakshani', 'SRMH Expert', 2, '2024-09-24 02:25:22', '2024-09-30 01:16:47'),
(4, 'YSMQPbDXX4UQFU3sGPWiRB2rOTWGkAZelZl7tWBr.png', 'Mr. Shah Haroon', 'Programmer', 2, '2024-09-24 02:25:48', '2024-09-30 01:17:22'),
(5, 'uvb0reGfvUJ3PkgfuyG4nhcbhY4fP1MDbNw65Vqs.png', 'Dr. Iftikhar Ahmed', 'AI Expert', 2, '2024-09-24 02:26:15', '2024-09-30 01:18:08'),
(6, 'jZfWUOUWZFVMip9YrWezjs8auBSoEOTGYG9uCwZz.png', 'Dr. Shyam Raj Upreti', 'epidemiologist', 2, '2024-09-24 02:26:43', '2024-09-30 01:18:28'),
(7, 'f8OPuQiXkowUoyDfKc49B7n8edN0Pi0ptEOZTYTP.png', 'Mr. Kamran Aslam', 'Digital Health Expert', 2, '2024-09-24 02:27:12', '2024-09-30 01:19:02'),
(8, 'Um0nyD5cGYsG1pIrpAk0DdI328jCkf8WJKt3YdRd.png', 'Mr. Shabbir Ahmad', 'Finance And Accounting Manager', 3, '2024-09-24 02:30:20', '2024-09-30 01:19:22'),
(9, '2SKOu88LWxYf19wfxfMQv86O5wZzT5Aa34wdlFqm.png', 'Mr. Pramod Bajracharya', 'Finance Lead', 3, '2024-09-24 02:30:47', '2024-09-30 01:19:58'),
(10, '7z7xj6q8srtLV4hgDhB2G7qbuZv6w6vP5d2OUXWQ.png', 'Ms. Rakshya Amatya', 'Research Associate', 3, '2024-09-24 02:31:09', '2024-09-30 01:20:17'),
(11, 'hQhT42yPEvNe9u3nJA1wRt7YYAtl1Swik1IjCbcW.png', 'Mr. Kshitij Karki', 'Research Associate', 3, '2024-09-24 02:31:37', '2024-09-30 01:20:41'),
(12, 'XKMWUvzxMD816vyvwU2CWidbPzUwg89GwMFAbheB.png', 'Ms. Simran Siraj', 'Senior Communication Associate', 4, '2024-09-24 02:32:59', '2024-09-30 01:21:34'),
(13, 'yTL3psyct7oLNXFfHO2hDly66e2nZRz57JBAzBBP.png', 'Ms. Zainab Farid', 'Communication Associate', 4, '2024-09-24 02:33:24', '2024-09-30 01:21:52'),
(14, 'KOOciOsbOdDMkDocZYnJft34oZRqHl351ucsll7x.png', 'Ms. Sushmita Adhikari', 'Secretariat Coordinator', 4, '2024-09-24 02:33:51', '2024-09-30 01:22:08'),
(15, 'N725A6xEB0dm0R800BbqChJX0tEpgucJK0kQjyzF.png', 'Ms. Tejaswi Pahari', 'Communication Associate', 4, '2024-09-24 02:34:14', '2024-09-30 01:22:21');

-- --------------------------------------------------------

--
-- Table structure for table `our_team_roles`
--

CREATE TABLE `our_team_roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `role` varchar(255) DEFAULT NULL,
  `bgColor` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `our_team_roles`
--

INSERT INTO `our_team_roles` (`id`, `role`, `bgColor`, `created_at`, `updated_at`) VALUES
(1, 'Leadership', '#FFDBCC', '2024-09-24 06:02:39', '2024-09-24 06:02:39'),
(2, 'Technical Team', '#FFE5D9', '2024-09-24 06:02:39', '2024-09-24 06:02:39'),
(3, 'Implementation Team', '#F6E1E4', '2024-09-24 06:03:27', '2024-09-24 06:03:27'),
(4, 'Communications Team', '#BBBFFF', '2024-09-24 06:03:27', '2024-09-24 06:03:27');

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE `pages` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` text DEFAULT NULL,
  `slug` text DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `heading` varchar(255) DEFAULT NULL,
  `sub_heading` varchar(255) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `type` enum('page','section') NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`id`, `name`, `slug`, `image`, `heading`, `sub_heading`, `description`, `type`, `user_id`, `created_at`, `updated_at`) VALUES
(16, 'Home', 'home', 'fc3d444a-d630-422b-8788-182f4727ae5b.webp', 'AI-Sarosh', 'AI for Sexual Reproductive and Maternal Health (SRMH) in South Asia', 'AI-Sarosh, Artificial Intelligence for Sexual and Reproductive Health for South Asia Hub, is a project funded by Canadian International Development Research Center (IDRC) for Artificial Intelligence for Global Health (AI4GH). The hub focuses on reducing the SRMH burden in South Asia by developing AI solutions to escalate, early detect, prevent and act on the health issues prominent in the region.', 'page', 1, '2024-09-10 06:13:00', '2024-09-10 06:47:58'),
(17, NULL, 'our-vision', NULL, 'Our Vision', NULL, 'We aim for a healthier South Asia where every citizen has access to the highest quality of Sexual, Reproductive, and Maternal Health (SRMH) services and resources. We envision a future where technology is utilized to make those services and resources more efficient, equitable, and accessible.', 'section', 1, '2024-09-10 06:13:19', '2024-09-10 07:15:18'),
(22, NULL, 'our-mission', NULL, 'Our Mission', NULL, 'Our mission is to create a unified, data-driven knowledge hub, powered by Artificial Intelligence (AI) and cutting-edge digital tools, to bridge gaps in access and care. We aim to bring about positive and equitable improvements to Sexual, Reproductive, and Maternal Health (SRMH) outcomes globally.', 'section', 1, '2024-09-10 06:49:45', '2024-09-25 05:34:43'),
(23, NULL, 'about-our-donor', '90835ea5-b2f4-4c8d-a322-f3ec4326ae02.svg', 'About Our Donor', NULL, 'International Development Research Centre (IDRC) is a Canadian government-funded organization that supports research in developing countries to promote sustainable and equitable development. Their mission is to support research that generates knowledge and innovative solutions to improve lives and livelihoods, reduce poverty, and address global challenges such as climate change, food security, and health. \n\n \n The organization provides grants and funding to researchers, institutions, and organizations in developing countries to conduct research, develop and implement solutions, and share their knowledge and findings with policymakers, communities, and other stakeholders. IDRC also works to promote gender equality, social inclusion, and diversity in research and development.', 'section', 1, '2024-09-10 23:31:33', '2024-09-10 23:35:52'),
(28, NULL, 'our-work', 'a3b8a0a5-0f37-4a5b-ac0f-c9b8f264a80d.svg', 'Our Work', NULL, 'Our teams across four countries in South Asia are working to resolve key SRMH challenges. Scroll below to know our work in your country.', 'section', 1, '2024-09-11 01:51:33', '2024-09-11 01:59:14'),
(29, NULL, 'library', 'yJ3zjBes1fbubOktyiNwJy36PshPw14hc6tKuPua.svg', 'Library', NULL, 'Meet the dynamic team behind our knowledge hub.', 'section', 1, '2024-09-12 23:13:34', '2024-09-12 23:36:33'),
(30, NULL, 'our-team', '3SeBoWQtBA1MP1VHz6nvG9XSNOPMHKRskkXEXDSJ.svg', 'Our Team', NULL, 'Meet the dynamic team behind our knowledge hub.', 'section', 1, '2024-09-13 02:38:36', '2024-09-13 02:38:36'),
(34, NULL, 'about-us', 'gsLRaWddYTaE9pbm4G0Dqg4AA3bOUUjbnIifC0t5.svg', 'About Us', NULL, 'Learn what motivated us to pioneer a regional knowledge hub that utilizes AI for health.', 'section', 1, '2024-09-23 03:38:21', '2024-09-25 05:37:32');

-- --------------------------------------------------------

--
-- Table structure for table `partners`
--

CREATE TABLE `partners` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `image` varchar(255) NOT NULL,
  `description` longtext NOT NULL,
  `page_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE `projects` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `university` varchar(255) DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `country_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `project_details`
--

CREATE TABLE `project_details` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `pi` varchar(255) NOT NULL,
  `co_pi` varchar(255) NOT NULL,
  `timeline` varchar(255) NOT NULL,
  `project_teams` longtext NOT NULL,
  `url` varchar(255) NOT NULL,
  `about_project` varchar(255) NOT NULL,
  `about_description` longtext NOT NULL,
  `bg_color` varchar(255) NOT NULL,
  `project_id` bigint(20) UNSIGNED NOT NULL,
  `country_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `reports`
--

CREATE TABLE `reports` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `organization` varchar(255) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `report_file` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `library_type_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `reports`
--

INSERT INTO `reports` (`id`, `title`, `organization`, `description`, `report_file`, `image`, `library_type_id`, `created_at`, `updated_at`) VALUES
(2, 'Artificial Intelligence for Sexual and Reproductive Health - South Asia HUB', 'Reproductive Health - South Asia HUB Co-design workshop report', '<h4 class=\"card-text main-color fw-lightr line-height-27  para-font-size main-color \" style=\"margin-right: 0px; margin-bottom: 0.5rem; margin-left: 0px; padding: 0px; line-height: 27px; font-size: var(--para-font-size); color: var(--heading-color); font-family: Raleway;\"><span style=\"font-weight: var(--font-weight-light) !important;\">This report contains detailed documentation of the purpose of AI-Sarosh and the </span><b>4 - day </b><span style=\"font-weight: var(--font-weight-light) !important;\">workshop and presentations that took place in </span><b>Colombo, Sri Lanka.</b><span style=\"font-weight: var(--font-weight-light) !important;\"> The sessions and presentations aimed to improve the design of project ideas and Strategies for all grant initiatives, ensuring Alignment with AI Saroshs overarching vision and objectives. The workshop focused on fostering knowledge sharing, facilitating mutual learning, and creating an immersive collaborative environment</span></h4>', '46x8yGe7rEs35qHnxQrw5HfBgKnoH8P4u2TITIDR.pdf', 'Nb4HzUGeJfqrQwodqDh0awuE3l3u5TypivZqwXPT.svg', 2, '2024-09-29 23:51:32', '2024-09-29 23:51:32'),
(4, 'Artificial Intelligence for Sexual and Reproductive Health - South Asia HUB', 'Reproductive Health - South Asia HUB Co-design workshop report', '<h4 class=\"card-text main-color fw-lightr line-height-27  para-font-size main-color \" style=\"margin-right: 0px; margin-bottom: 0.5rem; margin-left: 0px; padding: 0px; line-height: 27px; font-size: var(--para-font-size); color: var(--heading-color); font-family: Raleway;\"><span style=\"font-weight: var(--font-weight-light) !important;\">This report contains detailed documentation of the purpose of AI-Sarosh and the </span><b>4 - day </b><span style=\"font-weight: var(--font-weight-light) !important;\">workshop and presentations that took place in </span><b>Colombo, Sri Lanka.</b><span style=\"font-weight: var(--font-weight-light) !important;\"> The sessions and presentations aimed to improve the design of project ideas and Strategies for all grant initiatives, ensuring Alignment with AI Saroshs overarching vision and objectives. The workshop focused on fostering knowledge sharing, facilitating mutual learning, and creating an immersive collaborative environment</span></h4>', 'HYTpKv6z7Wr66W80BE45XvMB5FreEyWe93YzzXzX.pdf', '06sbzgKAnPlXeNFZWEeL6bAE22xgYVzfIotsS07N.png', 2, '2024-09-30 01:36:37', '2024-09-30 01:42:19');

-- --------------------------------------------------------

--
-- Table structure for table `sections`
--

CREATE TABLE `sections` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `description` longtext NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `social_url` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`social_url`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `logo`, `social_url`, `created_at`, `updated_at`) VALUES
(1, 'beed08f3-12dc-4553-9793-ef2f2b6cba4e.svg', '{\"fb_url\":\"https:\\/\\/www.facebook.com\\/\",\"insta_url\":\"https:\\/\\/www.instagram.com\\/\",\"youtube_url\":\"https:\\/\\/www.youtube.com\\/\",\"linkedin_url\":\"https:\\/\\/www.linkedin.com\\/\"}', '2024-09-10 07:42:20', '2024-09-11 02:42:36');

-- --------------------------------------------------------

--
-- Table structure for table `teams`
--

CREATE TABLE `teams` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `designation` varchar(255) DEFAULT NULL,
  `frontend_role_id` bigint(20) UNSIGNED NOT NULL,
  `page_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `thematic_services`
--

CREATE TABLE `thematic_services` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `description` longtext NOT NULL,
  `image` varchar(255) NOT NULL,
  `type` varchar(255) DEFAULT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `thematic_services`
--

INSERT INTO `thematic_services` (`id`, `title`, `slug`, `description`, `image`, `type`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 'Multi-disciplinary Approach', 'multi-disciplinary-approach', 'To catalyze a multi-disciplinary approach using AI technologies to solve key issues in SRMH in South Asia, fostering collaboration across various fields.', 'L0eWcA6G42oPwEGs6xKGjp0yXCMWcOpxzmZ0EzgX.svg', 'service', 1, '2024-09-23 05:28:34', '2024-09-23 05:28:34'),
(2, 'Potential Opportunities', 'potential-opportunities', 'To identify and facilitate opportunities to enhance existing programs, develop new ones, improve service quality and access, and boost client knowledge in SRMH throughout South Asia.', 'mIeFE3fMxdCmBP7cZc0IfpfjClzggfHEZjfN1nav.svg', 'service', 1, '2024-09-23 05:29:34', '2024-09-23 05:29:34'),
(3, 'Knowledge Sharing', 'knowledge-sharing', 'To promote knowledge sharing on the use of AI for SRMH between countries in South Asia and other regions globally, fostering international collaboration and innovation.', 'vVvrm7pEzEoXG67JJ3fCVZc9VYzMh4k8OL04JwuF.svg', 'service', 1, '2024-09-23 05:30:00', '2024-09-23 05:30:00'),
(4, 'AI Innovations', 'ai-innovations', 'To award and manage projects that use AI innovations to address key challenges in SRMH in the South Asia region, driving impactful and sustainable solutions.', 'v69cH6jwLqtiHzU5D5uPzoVQdCE1KH2IeRojRqfn.svg', 'service', 1, '2024-09-23 05:30:33', '2024-09-23 05:30:33'),
(5, 'Maternal Mental Health', 'maternal-mental-health', 'Mental health conditions during pregnancy are considered a “norm”. The limited access to mental health services, especially for pregnant/postpartum women, and to address the stigma associated with mental health can be a potential low cost AI solution. Innovative AI based ideas for well-being during pregnancy are a priority for AI-Sarosh.', 'rJqPnuMkKE8VqzdqJLhtzkk27BaRQSs6ycOkqhFY.svg', 'thematic_area', 1, '2024-09-23 05:36:51', '2024-09-23 06:07:36'),
(6, 'Sexual and Reproductive Health (SRH) Services', 'sexual-and-reproductive-health-srh-services', 'Improving access to SRMH services, including counseling and services for sexually transmitted infections (STIs) and contraception, especially among adolescents.', 'pmF4ULlz4J9jEA5VnsyiBISjKIdMbGCj9nmnwAvv.svg', 'thematic_area', 1, '2024-09-23 05:37:24', '2024-09-23 05:37:24'),
(8, 'Family Planning and Male Partner Involvement', 'family-planning-and-male-partner-involvement', 'Addressing the unmet need for family planning, especially among disadvantaged populations, to help reduce Total Fertility Rate (TFR) and Adolescent Birth Rate (ABR). Increase male partner engagement and support in family planning.', 'diNTKoMVnfocnvcQxmuktwLilBCh5R17TLLq7RpQ.svg', 'thematic_area', 1, '2024-09-23 05:39:24', '2024-09-23 05:39:24'),
(9, 'Maternal Health', 'maternal-health', 'Improving access to quality maternal health services, including prenatal care, skilled birth attendance, and emergency obstetric care, to further reduce maternal mortality ratio (MMR) and development, and/or deployment of innovative and sustainable ideas.', 'BvJts7teBZOLsMMAYcHLYd0uNe3SzAbdMTeceuHX.svg', 'thematic_area', 1, '2024-09-23 05:39:57', '2024-09-23 05:39:57'),
(10, 'Adolescent Sexual and Reproductive Health (ASRH)', 'adolescent-sexual-and-reproductive-health-asrh', 'Improving access to quality maternal health services, including prenatal care, skilled birth attendance, and emergency obstetric care, to further reduce maternal mortality ratio (MMR) and development, and/or deployment of innovative and sustainable ideas.', 'rU8xcdczbm28A9SikrepuPu4HeDjGysUNfnh7CwV.svg', 'thematic_area', 1, '2024-09-23 05:40:36', '2024-09-23 06:09:21');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Ai', 'Sarosh', 'admin@alsarosh.com', NULL, '$2y$10$XI48iafwLL0Eu0X9YX5xbOAaqTc6u6P8Zl9PLs6LFzaEHLrmWu7MO', NULL, '2024-09-09 07:34:05', '2024-09-09 07:34:05');

-- --------------------------------------------------------

--
-- Table structure for table `videos`
--

CREATE TABLE `videos` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `organization` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `iframe_url` varchar(255) DEFAULT NULL,
  `video_link` varchar(255) DEFAULT NULL,
  `library_type_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `videos`
--

INSERT INTO `videos` (`id`, `title`, `name`, `organization`, `image`, `iframe_url`, `video_link`, `library_type_id`, `created_at`, `updated_at`) VALUES
(3, 'Opening Speech', 'By Dr. Imran', 'PHC Global', 'zzcCsa7BkczfWWPuV2KZ3OXq94rLQck1t1GVGdkM.png', NULL, 'QgxqxocxKKIpX0gii2n7b4CDBpE0wBe2UPRtve6n.mp4', 4, '2024-09-26 04:38:45', '2024-09-30 03:14:44'),
(4, 'Keynote Speech', 'By Mr. Eric Walsh dd', 'High Commissioner Canada in Sri Lanka and Maldives', 'IlacEyEwwo5FIp4D9IKXAUOxOofe1XNspBJeIa4U.png', NULL, 'EATLjPlNnXWJJWRmgsK1PlKpghkjLftfsoe8aqlr.mp4', 4, '2024-09-26 04:45:50', '2024-09-30 03:15:03');

-- --------------------------------------------------------

--
-- Table structure for table `webinars`
--

CREATE TABLE `webinars` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `redirect_url` varchar(255) DEFAULT NULL,
  `webinar_date` date DEFAULT NULL,
  `library_type_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `webinars`
--

INSERT INTO `webinars` (`id`, `title`, `image`, `redirect_url`, `webinar_date`, `library_type_id`, `created_at`, `updated_at`) VALUES
(2, 'AI-Sarosh Grant Award Review Webinar', 'gOaC7PYa1churpd54gyfPzTXYEjXN2NUfMJCmwz6.png', 'https://www.youtube.com/watch?v=pa_jTzM_HPA', '2023-04-25', 1, '2024-09-25 06:33:03', '2024-09-30 01:26:31'),
(3, 'Webinar on AI-Sarosh 2023 Grant Cycle-full Proposal Development', 'zz2HbubAxyW70iXNUDCaxxZL0IUWMRxXpn2SVMmT.png', 'https://www.youtube.com/watch?v=f4FW4Ug4W1w', '2023-05-12', 1, '2024-09-25 06:48:57', '2024-09-30 01:29:20'),
(4, 'Mindful Motherhood: How South Asia is coping with Perinatal Depression', 'yGbBLVkScCwf1qAxlEZkBRgvxlYpRb1UVD27awid.png', 'https://www.youtube.com/watch?v=4W9ROoajYXs', '2023-05-15', 1, '2024-09-25 06:54:48', '2024-09-30 01:29:35'),
(5, 'Reviewers webinar for AI-Sarosh proposal evaluation', '5BOtWQECsGHqp3AK02MsbFujrwLrct1Y5diLMNKi.png', 'https://www.youtube.com/watch?v=nyLCcXvOBIs', '2023-06-08', 1, '2024-09-25 06:55:08', '2024-09-30 01:29:48'),
(6, 'Grantee Co-design workshop', 'PfsuSE3ELk9iAEo3c35wAtPRfG7tFAMxeZrtPJch.png', 'https://www.youtube.com/watch?v=IjQavz12SHs', '2023-08-30', 1, '2024-09-25 06:55:30', '2024-09-30 01:30:02');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `articles`
--
ALTER TABLE `articles`
  ADD PRIMARY KEY (`id`),
  ADD KEY `articles_library_type_id_foreign` (`library_type_id`);

--
-- Indexes for table `countries`
--
ALTER TABLE `countries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `frontend_roles`
--
ALTER TABLE `frontend_roles`
  ADD PRIMARY KEY (`id`),
  ADD KEY `frontend_roles_user_id_foreign` (`user_id`);

--
-- Indexes for table `galleries`
--
ALTER TABLE `galleries`
  ADD PRIMARY KEY (`id`),
  ADD KEY `galleries_user_id_foreign` (`user_id`);

--
-- Indexes for table `library_types`
--
ALTER TABLE `library_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `our_clients`
--
ALTER TABLE `our_clients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `our_teams`
--
ALTER TABLE `our_teams`
  ADD PRIMARY KEY (`id`),
  ADD KEY `our_teams_our_team_roles_id_foreign` (`our_team_roles_id`);

--
-- Indexes for table `our_team_roles`
--
ALTER TABLE `our_team_roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `pages_slug_unique` (`slug`) USING HASH,
  ADD KEY `pages_user_id_foreign` (`user_id`);

--
-- Indexes for table `partners`
--
ALTER TABLE `partners`
  ADD PRIMARY KEY (`id`),
  ADD KEY `partners_page_id_foreign` (`page_id`),
  ADD KEY `partners_user_id_foreign` (`user_id`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`id`),
  ADD KEY `projects_country_id_foreign` (`country_id`);

--
-- Indexes for table `project_details`
--
ALTER TABLE `project_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `project_details_project_id_foreign` (`project_id`),
  ADD KEY `project_details_country_id_foreign` (`country_id`);

--
-- Indexes for table `reports`
--
ALTER TABLE `reports`
  ADD PRIMARY KEY (`id`),
  ADD KEY `reports_library_type_id_foreign` (`library_type_id`);

--
-- Indexes for table `sections`
--
ALTER TABLE `sections`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `teams`
--
ALTER TABLE `teams`
  ADD PRIMARY KEY (`id`),
  ADD KEY `teams_frontend_role_id_foreign` (`frontend_role_id`),
  ADD KEY `teams_page_id_foreign` (`page_id`),
  ADD KEY `teams_user_id_foreign` (`user_id`);

--
-- Indexes for table `thematic_services`
--
ALTER TABLE `thematic_services`
  ADD PRIMARY KEY (`id`),
  ADD KEY `services_user_id_foreign` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `videos`
--
ALTER TABLE `videos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `videos_library_type_id_foreign` (`library_type_id`);

--
-- Indexes for table `webinars`
--
ALTER TABLE `webinars`
  ADD PRIMARY KEY (`id`),
  ADD KEY `webinars_library_type_id_foreign` (`library_type_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `articles`
--
ALTER TABLE `articles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `countries`
--
ALTER TABLE `countries`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `frontend_roles`
--
ALTER TABLE `frontend_roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `galleries`
--
ALTER TABLE `galleries`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `library_types`
--
ALTER TABLE `library_types`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `our_clients`
--
ALTER TABLE `our_clients`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `our_teams`
--
ALTER TABLE `our_teams`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `our_team_roles`
--
ALTER TABLE `our_team_roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `partners`
--
ALTER TABLE `partners`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `projects`
--
ALTER TABLE `projects`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `project_details`
--
ALTER TABLE `project_details`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `reports`
--
ALTER TABLE `reports`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `sections`
--
ALTER TABLE `sections`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `teams`
--
ALTER TABLE `teams`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `thematic_services`
--
ALTER TABLE `thematic_services`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `videos`
--
ALTER TABLE `videos`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `webinars`
--
ALTER TABLE `webinars`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `articles`
--
ALTER TABLE `articles`
  ADD CONSTRAINT `articles_library_type_id_foreign` FOREIGN KEY (`library_type_id`) REFERENCES `library_types` (`id`);

--
-- Constraints for table `frontend_roles`
--
ALTER TABLE `frontend_roles`
  ADD CONSTRAINT `frontend_roles_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `galleries`
--
ALTER TABLE `galleries`
  ADD CONSTRAINT `galleries_page_id_foreign` FOREIGN KEY (`page_id`) REFERENCES `pages` (`id`),
  ADD CONSTRAINT `galleries_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `our_teams`
--
ALTER TABLE `our_teams`
  ADD CONSTRAINT `our_teams_our_team_roles_id_foreign` FOREIGN KEY (`our_team_roles_id`) REFERENCES `our_team_roles` (`id`);

--
-- Constraints for table `pages`
--
ALTER TABLE `pages`
  ADD CONSTRAINT `pages_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `partners`
--
ALTER TABLE `partners`
  ADD CONSTRAINT `partners_page_id_foreign` FOREIGN KEY (`page_id`) REFERENCES `pages` (`id`),
  ADD CONSTRAINT `partners_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `projects`
--
ALTER TABLE `projects`
  ADD CONSTRAINT `projects_country_id_foreign` FOREIGN KEY (`country_id`) REFERENCES `countries` (`id`);

--
-- Constraints for table `project_details`
--
ALTER TABLE `project_details`
  ADD CONSTRAINT `project_details_country_id_foreign` FOREIGN KEY (`country_id`) REFERENCES `countries` (`id`),
  ADD CONSTRAINT `project_details_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `countries` (`id`);

--
-- Constraints for table `reports`
--
ALTER TABLE `reports`
  ADD CONSTRAINT `reports_library_type_id_foreign` FOREIGN KEY (`library_type_id`) REFERENCES `library_types` (`id`);

--
-- Constraints for table `teams`
--
ALTER TABLE `teams`
  ADD CONSTRAINT `teams_frontend_role_id_foreign` FOREIGN KEY (`frontend_role_id`) REFERENCES `pages` (`id`),
  ADD CONSTRAINT `teams_page_id_foreign` FOREIGN KEY (`page_id`) REFERENCES `pages` (`id`),
  ADD CONSTRAINT `teams_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `thematic_services`
--
ALTER TABLE `thematic_services`
  ADD CONSTRAINT `services_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `videos`
--
ALTER TABLE `videos`
  ADD CONSTRAINT `videos_library_type_id_foreign` FOREIGN KEY (`library_type_id`) REFERENCES `library_types` (`id`);

--
-- Constraints for table `webinars`
--
ALTER TABLE `webinars`
  ADD CONSTRAINT `webinars_library_type_id_foreign` FOREIGN KEY (`library_type_id`) REFERENCES `library_types` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
